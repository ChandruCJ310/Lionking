<style>
      /* Dynamic Top Ad Banner Styling */
      .top-ad-container {
        display: flex;
        height: 250px;
        justify-content: center;
        align-items: center;
        padding: 0;
        background-color: #ffcc00;
        transition: all 1s ease; /* Smooth transition */
      }

      .top-ad-banner
    {
        background-color: #ffffff;
        color: #003366;
        font-weight: bold;
        text-align: center;
        border-radius: 10px;
        margin: 5px;
        height: 200px;
        width: 100%;
      }

	  /* Styling for the slider container */
      #top-ad {
        position: relative;
        overflow: hidden;
        width: 100.4%;
        transform: translateY(-60px);
        /* Full width */
      }



      .slider-wrapper {
        display: flex;
        transition: transform 1s ease; /* Smooth transition for sliding */
      }

      .slider-item {
        min-width: 100%;
        transition: opacity 1s ease; /* Fade effect for items */
        display: flex;
        justify-content: center;
        align-items: center;
      }

      .slider-item .top-ad-banner {
        width: 100%; /* Full width for each ad banner */
        padding: 20px;
        text-align: center;
        background-color: #f1f1f1;
        border: 1px solid #ddd;
      }

      .slider-item:not(.active) {
        opacity: 0;
        visibility: hidden;
      }

      /* Optional: Styling for the active state */
      .slider-item.active {
        opacity: 1;
        visibility: visible;
      }

	    /* .top-ad-container {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 0px;
        background-color: #ffcc00;
        height: 250px;
        overflow: hidden;
        position: relative;
      } */

      .top-ad-banner {
        display: flex;
        justify-content: center;
        align-items: center;
        margin: 1px; /* Removes extra margins */
        padding: 1px; /* Removes extra padding */
      }

      .ad-banner-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .top-ad-container {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 0px;
        background-color: #ffcc00;
        height: 200px;
        overflow: hidden;
      }
      .top-ad-banner img {
        max-width: 100%;
        max-height: 250%;
        object-fit: cover;
        display: block;

      }
      .top-ad-container1 {
    display: flex;
    flex-direction: column; /* Stack image and details vertically */
    align-items: center; /* Center content */
    justify-content: center;
    background-color: #ffffff;
    padding: 2px;
    border-radius: 10px;
    max-width: 220px; /* Adjusted for a compact look */
    margin: auto;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
    overflow: hidden;
    width: 140%;
    height: 110%;
}

.top-ad-banner1 {
    width: 150px; /* Fixed square size */
    height: 135px;
    overflow: hidden;
    border-radius: 0; /* Keeps it square */
    margin-bottom: 8px; /* Space between image and details */
}

.top-ad-banner1 img {

    width: 100%;
    height: 100%;
    object-fit: cover; /* Ensures the image fills the square */
    border-radius:10px; /* Removes rounded corners */
}


.details-container {
    background-color: #fff;
    padding: 6px;
    border-radius: 5px;
    width: 100%;
    font-size: 12px;
    word-wrap: break-word;
    overflow-wrap: break-word;
}

.details-container h2 {
    font-size:15px !important;
    margin: 4px 0;
    color: #003366;

}

.details-container p {
    font-size: 11px !important;
    margin: 2px 0;
    color: #333;
    line-height: 1.2;
}

@media (max-width: 768px) {
    #top-ad1, #top-ad {
        display: flex;
        flex-direction: column; /* Force each div into its own row */
        width: 100%; /* Ensure full width */
    }

    .top-ad-container1, .top-ad-container {
        width: 100%; /* Make sure both take up full width */
        display: block; /* Ensure each container stacks */
        margin-bottom:; /* Add space between them */
    }

    .top-ad-banner1 img {
        width: 100%; /* Ensure the image is responsive */
        height: auto;
        display: block; /* Prevent inline spacing issues */
    }

    #top-ad {
    position: relative;
    overflow: hidden;
    width: 100%;
    transform: translateY(-70px);
    height: 126px;
}

.top-ad-container1 {
  max-width:400px;
  height:85px;
  border-radius: 0px;
}
.details-container{
  height:50px;
}

.details-container h2 {
font-size:13px !important;
}

.details-container p {

font-size:12px !important;
}

.top-ad-banner1 img{
  height:70px;
  width:80px;
  margin-left: 60px;
  margin-top:28px;
  border-radius: 5px;
}
.top-ad-banner1{
  margin-bottom: 0px;
}
.top-ad-banner{
  border-radius:0px;
}
.top-ad-banner img {
  border-radius: 1px;
}
.details-container {
        flex: 1; /* Allow text to take remaining space */
    }

    #top-ad1 {
        display: flex;
        flex-direction: row; /* Arrange items in a row */
        align-items: center; /* Align items vertically */
        justify-content: start; /* Align items to the left */
        gap: 10px; /* Add space between elements */
        flex-wrap: nowrap; /* Prevent wrapping */
    }
}

        </style>



    <!-- Top Ad Banner (Dynamic) -->
    @if(isset($members) && $members->isNotEmpty())
    @foreach($members as $member)
        <div id="top-ad1" class="top-ad-container1">
            <div class="top-ad-banner1">
                <img src="{{ asset('storage/app/public/' . $member->image) }}" alt="{{ $member->name }}" class="ban" />
            </div>
            <div class="details-container">
                <h2 class="fs-4">{{ $member->name }}</h2>
                <p class="fs-6 mb-1"><b></b>{{ $member->role }}</p>
            </div>
        </div>
    @endforeach
@else
    <p>No members found.</p>
@endif


    <?php


// Fetch banners from different tables, including the 'url' column

use Illuminate\Support\Facades\DB;

$banners_10000 = DB::table('banner_10000')->select('image_path', 'url')->get();
$banners_5000 = DB::table('banner_5000')->select('image_path', 'url')->get();
$banners_1000 = DB::table('banner_1000')->select('image_path', 'url')->get();

// Convert the banner data to JSON format for JavaScript
$bannerData = [
    '10000' => $banners_10000,
    '5000' => $banners_5000,
    '1000' => $banners_1000
];
?>

<div id="top-ad" class="top-ad-container"></div>

<script>
    // Convert PHP data to JavaScript format
    let bannerData = <?php echo json_encode($bannerData); ?>;

    // Initial state for banner rotation
    let topBannerState = 1;

    // Function to update the top ad banner dynamically
    function updateTopAdBanner() {
        const topAdContainer = document.getElementById("top-ad");
        topAdContainer.innerHTML = ""; // Clear current content

        let banners = [];

        // Select banners based on state
        if (topBannerState === 1) {
            banners = bannerData['10000'];
        } else if (topBannerState === 2) {
            banners = bannerData['5000'];
        } else if (topBannerState === 3) {
            banners = bannerData['1000'];
        }

        // Check if banners exist and generate HTML dynamically
        if (banners.length > 0) {
            banners.forEach(banner => {
                topAdContainer.innerHTML += `
                    <div class="top-ad-banner">
                        <a href="${banner.url}" target="_blank">
                            <img src="/storage/app/public/${banner.image_path}" alt="Top Ad Banner" class="ad-banner-image" />
                        </a>
                    </div>
                `;
            });
        } else {
            topAdContainer.innerHTML = `<p class="text-center">No Banners Available</p>`;
        }

        // Rotate between banner sets
        topBannerState = topBannerState === 3 ? 1 : topBannerState + 1;
    }

    // Automatically update banners every 3 seconds
    setInterval(updateTopAdBanner, 3000);

    // Load banners on page load
    updateTopAdBanner();
</script>





    <!-- JavaScript for Dynamic Banner Changes -->


    <script>
      // Get all banner images and initialize index for the banner
      const bannerImages = document.querySelectorAll(".banner-image");
      let currentBannerIndex = 0;

      // Function to show the next banner image
      function showNextImage() {
        // Hide the current image
        bannerImages[currentBannerIndex].classList.remove("active");

        // Update the index to the next image
        currentBannerIndex = (currentBannerIndex + 1) % bannerImages.length;

        // Show the next image
        bannerImages[currentBannerIndex].classList.add("active");
      }

      // Get all carousel items and initialize index for the carousel
      const scrollContainer = document.querySelector(".scroll-container");
      const carouselItems = scrollContainer.querySelectorAll(".carousel-item");
      let currentCarouselIndex = 0;

      // Function to scroll carousel items
      function scrollItems() {
        carouselItems.forEach((item, index) => {
          item.style.transform = `translateY(${
            (index - currentCarouselIndex) * 100
          }%)`;
        });

        // Update index for the next item
        currentCarouselIndex =
          (currentCarouselIndex + 1) % carouselItems.length;
      }

      // Set intervals for both functions
      setInterval(showNextImage, 3000); // Interval for banner images
      setInterval(scrollItems, 6000); // Interval for carousel items
    </script>



