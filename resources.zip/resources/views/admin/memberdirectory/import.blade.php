@extends('MasterAdmin.layout')

@section('content')

@endsection