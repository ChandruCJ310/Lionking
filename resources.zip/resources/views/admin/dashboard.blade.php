@extends('MasterAdmin.layout')

@section('content')
    <h2 class="text-center fw-bold" style="color: #e91e63; margin-top: 20px;">
         Lion, Welcome to Lions Club Admin!
    </h2>
@endsection
